//
//  AddExpenseScreen.swift
//  BudgetAppWorkshop
//
//  Created by Mohammad Azam on 3/27/24.
//

import SwiftUI
import SwiftData

struct ExpenseConfig {
    
    var name: String = ""
    var price: Double?
    var quantity: Int = 1
    
    var isValid: Bool {
        guard let price = price else { return false }
        return !name.isEmptyOrWhitespace && price > 0 && quantity > 0
    }
}

struct AddExpenseScreen: View {
    
    @Environment(\.dismiss) private var dismiss
    @State private var expenseConfig = ExpenseConfig()
    
    var body: some View {
        Form {
            Section("Add Expense") {
                /*
                TextField("Expense name", text: $expenseConfig.name)
                TextField("Expense price", value: $expenseConfig.price, format: .number)
                TextField("Expense quantity", value: $expenseConfig.quantity, format: .number)
                 */
                Button(action: {
                    // save expenses
                    if expenseConfig.isValid {
                        // save expenses
                        
                    }
                }, label: {
                    Text("Save Expense")
                        .frame(maxWidth: .infinity)
                }).buttonStyle(.borderedProminent)
                    .listRowSeparator(.hidden)
                
            }
        }.navigationTitle("Add Expense")
    }
}

#Preview { @MainActor in
    NavigationStack {
        AddExpenseScreen() 
    }
}
